#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ======================
// USER CONFIG (แก้ตรงนี้ก่อนอัปโหลด)
// ======================
// WiFi
const char* WIFI_SSID = "Wifiname";
const char* WIFI_PASS = "password";

// MQTT
const char* MQTT_BROKER = "broker.emqx.io";
const uint16_t MQTT_PORT = 1883;


// เปลี่ยน prefix ได้ตรงนี้ เช่น "idt", "dgt", "lab1"
const char* TOPIC_PREFIX = "edit here";

// ส่งค่าทุกกี่ ms
const uint32_t PUBLISH_INTERVAL_MS = 1000;

// ======================
// PIN DEFINITIONS
// ======================
#define DHTPIN 23
#define DHTTYPE DHT22
#define LDR_PIN 34
#define RESET_PIN 16
#define BUZZER_PIN 18
const int ledPins[6] = {15, 12, 13, 32, 33, 2};  // LED1..LED6

DHT dht(DHTPIN, DHTTYPE);

WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);

// Topics (จะประกอบจาก prefix ตอน runtime)
String topic_temp;
String topic_hum;
String topic_ldr;
String topic_buzzer;
String topic_led_base; // prefix + "/led/led"

// MQTT client id (สุ่ม)
char mqtt_client_id[64];

// ======================
// Helper: build topics
// ======================
void buildTopics() {
  topic_temp     = String(TOPIC_PREFIX) + "/temperature";
  topic_hum      = String(TOPIC_PREFIX) + "/humidity";
  topic_ldr      = String(TOPIC_PREFIX) + "/ldr";
  topic_buzzer   = String(TOPIC_PREFIX) + "/buzzer";
  topic_led_base = String(TOPIC_PREFIX) + "/led/led"; // + 1..6
}

// ======================
// Helper: random client id
// ======================
void buildClientId() {
  // ใช้ MAC + random กันชน
  uint32_t r = (uint32_t)esp_random();
  String id = String(TOPIC_PREFIX) + "_LDR_DHT_" + WiFi.macAddress() + "_" + String(r, HEX);
  id.replace(":", "");
  id.toUpperCase();
  strlcpy(mqtt_client_id, id.c_str(), sizeof(mqtt_client_id));
}

// ======================
// WiFi connect
// ======================
void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  Serial.print("Connecting WiFi");
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
    // ถ้าอยากตั้ง timeout ก็เพิ่มได้
    if (millis() - t0 > 20000) {
      Serial.println("\nWiFi connect timeout -> restart");
      ESP.restart();
    }
  }
  Serial.println("\nWiFi connected");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

// ======================
// MQTT callback
// ======================
void callback(char *topic, byte *payload, unsigned int length) {
  // แปลง payload เป็น String แบบปลอดภัย
  String message;
  message.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) message += (char)payload[i];
  message.trim();
  message.toLowerCase();

  String topicStr = String(topic);
  Serial.printf("Message from [%s]: %s\n", topicStr.c_str(), message.c_str());

  // Buzzer control: <prefix>/buzzer
  if (topicStr == topic_buzzer) {
    digitalWrite(BUZZER_PIN, (message == "on") ? HIGH : LOW);
    Serial.printf("Buzzer %s\n", message.c_str());
    return;
  }

  // LED control: <prefix>/led/led1 .. led6
  for (int i = 1; i <= 6; i++) {
    String t = topic_led_base + String(i);
    if (topicStr == t) {
      digitalWrite(ledPins[i - 1], (message == "on") ? HIGH : LOW);
      Serial.printf("LED%d %s\n", i, message.c_str());
      return;
    }
  }
}

// ======================
// MQTT connect
// ======================
void connectMQTT() {
  mqttClient.setServer(MQTT_BROKER, MQTT_PORT);

  while (!mqttClient.connected()) {
    Serial.println("Connecting to MQTT...");

    // client id ต้องมีแล้ว
    if (mqttClient.connect(mqtt_client_id)) {
      Serial.println("MQTT connected");
      Serial.print("ClientID: ");
      Serial.println(mqtt_client_id);

      // subscribe ตาม prefix
      mqttClient.subscribe(topic_buzzer.c_str());
      for (int i = 1; i <= 6; i++) {
        String t = topic_led_base + String(i);
        mqttClient.subscribe(t.c_str());
      }

    } else {
      Serial.print("failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println(" try again in 2 seconds");
      delay(2000);
    }
  }
}

// ======================
// Setup
// ======================
void setup() {
  Serial.begin(115200);

  pinMode(RESET_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  for (int i = 0; i < 6; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }

  dht.begin();

  // ปุ่ม RESET_PIN: ตอนนี้ให้ “รีสตาร์ทอย่างเดียว” (เพราะไม่มี config เก็บแล้ว)
  if (digitalRead(RESET_PIN) == LOW) {
    Serial.println("Reset pressed -> restart");
    digitalWrite(BUZZER_PIN, HIGH);
    delay(300);
    digitalWrite(BUZZER_PIN, LOW);
    delay(300);
    ESP.restart();
  }

  buildTopics();
  connectWiFi();
  buildClientId();

  mqttClient.setCallback(callback);
  connectMQTT();

  // Startup beep
  for (int i = 0; i < 2; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(200);
    digitalWrite(BUZZER_PIN, LOW);
    delay(200);
  }
}

// ======================
// Loop
// ======================
uint32_t lastPub = 0;

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
    // เปลี่ยน WiFi แล้ว client id ควร rebuild
    buildClientId();
  }

  if (!mqttClient.connected()) {
    connectMQTT();
  }
  mqttClient.loop();

  uint32_t now = millis();
  if (now - lastPub >= PUBLISH_INTERVAL_MS) {
    lastPub = now;

    float temp = dht.readTemperature();
    float hum  = dht.readHumidity();
    int ldr    = analogRead(LDR_PIN);

    // กันค่าอ่าน DHT พัง (NaN)
    if (!isnan(temp)) mqttClient.publish(topic_temp.c_str(), String(temp, 2).c_str());
    if (!isnan(hum))  mqttClient.publish(topic_hum.c_str(), String(hum, 2).c_str());
    mqttClient.publish(topic_ldr.c_str(), String(ldr).c_str());
  }
}

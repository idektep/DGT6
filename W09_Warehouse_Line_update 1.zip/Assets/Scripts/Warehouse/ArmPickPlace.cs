using System.Collections;
using UnityEngine;

// Moves the arm's real joints to pick a box and put it down somewhere else.
// Each target point is turned into joint angles by a small numeric IK solver.
public class ArmPickPlace : MonoBehaviour
{
    [Header("Joints")]
    public Transform axis1;             // base, turns about local Y
    public Transform axis2;             // shoulder, turns about local X
    public Transform axis3;             // elbow, turns about local X
    public Transform axis4;             // wrist, turns about local X
    public Transform gripPoint;         // between the finger tips, +Z along the fingers

    [Header("Fingers (they slide along local X)")]
    public Transform clampU;
    public Transform clampD;
    public float fingersOpen = 0.0025f;     // per finger from the modelled pose: 30 mm gap
    public float fingersClosed = -0.0025f;  // per finger from the modelled pose: 20 mm gap, one ShelfBox20

    // Set by WarehouseCycle
    [HideInInspector] public float fingerSpeed = 0.01f;     // m/s
    [HideInInspector] public float jointSpeed = 45f;        // degrees/s of the joint with the furthest to go
    [HideInInspector] public float hoverHeight = 0.05f;     // height above a pick or drop point, on the way in and out
    [HideInInspector] public float carryRadius = 0.12f;     // while swinging: this close to the base...
    [HideInInspector] public float carryHeight = 0.15f;     // ...and this high, so the box clears the Y axis end

    // Axis 1 is the Week10 joint limit. Axes 2 to 4 are the RobotArm_MQTT servo limits (servo degrees - 90).
    static readonly Vector2[] Limits = { new Vector2(-90f, 90f), new Vector2(-80f, 20f), new Vector2(-60f, 60f), new Vector2(-60f, 90f) };
    static readonly float[] Home = { 0f, 10f, 20f, -30f };    // parked upright: fingers clear of the base and the AGV

    const float TiltWeight = 0.0002f;   // metres of position error worth one degree of gripper tilt, while solving
    float[] pose = new float[4];
    Vector3 clampUStart;
    Vector3 clampDStart;
    float fingers;
    Transform held;

    void Awake()
    {
        clampUStart = clampU.localPosition;
        clampDStart = clampD.localPosition;
        SetFingers(fingersOpen);
        pose = (float[])Home.Clone();
        Apply(pose);
    }

    public IEnumerator Pick(Transform box)
    {
        Vector3 pickPoint = box.position;

        yield return Reach(pickPoint + Vector3.up * hoverHeight);
        yield return Reach(pickPoint);
        yield return MoveFingers(fingersClosed);
        box.SetParent(null, true);
        held = box;
        yield return Reach(pickPoint + Vector3.up * hoverHeight);
    }

    public IEnumerator Place(Vector3 dropPoint)
    {
        Vector3 up = Vector3.up * hoverHeight;

        Vector3 toDrop = dropPoint - transform.position;
        toDrop.y = 0f;
        yield return Reach(transform.position + toDrop.normalized * carryRadius + Vector3.up * carryHeight);
        yield return Reach(dropPoint + up);
        yield return Reach(dropPoint);

        held.SetPositionAndRotation(dropPoint, Quaternion.identity);
        held = null;
        yield return MoveFingers(fingersOpen);
        yield return Reach(dropPoint + up);
        yield return MoveTo(Home);
    }

    // Used by Reset: let go of anything held, open the fingers and park upright, from whatever pose the arm is in
    public IEnumerator GoHome()
    {
        held = null;
        yield return MoveFingers(fingersOpen);
        yield return MoveTo(Home);
    }

    IEnumerator Reach(Vector3 target)
    {
        yield return MoveTo(Solve(target));
    }

    // All joints start and finish together, like setAllDegSmooth in RobotArm_MQTT
    IEnumerator MoveTo(float[] target)
    {
        float[] from = (float[])pose.Clone();
        float furthest = 0f;
        for (int i = 0; i < pose.Length; i++) furthest = Mathf.Max(furthest, Mathf.Abs(target[i] - from[i]));

        float duration = furthest / jointSpeed;
        for (float t = 0f; t < duration; t += Time.deltaTime)
        {
            float s = Mathf.SmoothStep(0f, 1f, t / duration);
            for (int i = 0; i < pose.Length; i++) pose[i] = Mathf.Lerp(from[i], target[i], s);
            Apply(pose);
            if (held != null) held.position = gripPoint.position;
            yield return null;
        }

        pose = (float[])target.Clone();
        Apply(pose);
        if (held != null) held.position = gripPoint.position;
    }

    IEnumerator MoveFingers(float target)
    {
        while (fingers != target)
        {
            SetFingers(Mathf.MoveTowards(fingers, target, fingerSpeed * Time.deltaTime));
            yield return null;
        }
    }

    void SetFingers(float offset)
    {
        fingers = offset;
        clampU.localPosition = clampUStart + new Vector3(offset, 0f, 0f);
        clampD.localPosition = clampDStart - new Vector3(offset, 0f, 0f);
    }

    void Apply(float[] q)
    {
        axis1.localRotation = Quaternion.Euler(0f, q[0], 0f);
        axis2.localRotation = Quaternion.Euler(q[1], 0f, 0f);
        axis3.localRotation = Quaternion.Euler(q[2], 0f, 0f);
        axis4.localRotation = Quaternion.Euler(q[3], 0f, 0f);
    }

    // Damped least squares on the real transforms: the grip point must reach the target,
    // and while there is freedom left the fingers should point as straight down as they can.
    float[] Solve(Vector3 target)
    {
        const int Iterations = 80;
        const float Probe = 0.25f;      // degrees
        const float Damping = 1e-7f;
        const float MaxStep = 6f;       // degrees

        float[] q = (float[])pose.Clone();
        q[0] = Mathf.Clamp(YawToward(target), Limits[0].x, Limits[0].y);

        float[,] jacobian = new float[4, 4];
        for (int iteration = 0; iteration < Iterations; iteration++)
        {
            // The last iterations ignore tilt, so the position ends up exact
            float tiltWeight = iteration < Iterations - 25 ? TiltWeight : 0f;
            float[] residual = Residual(q, target, tiltWeight);

            for (int j = 0; j < 4; j++)
            {
                float keep = q[j];
                q[j] = keep + Probe;
                float[] moved = Residual(q, target, tiltWeight);
                q[j] = keep;
                for (int i = 0; i < 4; i++) jacobian[i, j] = (residual[i] - moved[i]) / Probe;
            }

            float[] step = SolveNormalEquations(jacobian, residual, Damping);
            for (int j = 0; j < 4; j++)
            {
                q[j] = Mathf.Clamp(q[j] + Mathf.Clamp(step[j], -MaxStep, MaxStep), Limits[j].x, Limits[j].y);
            }
        }

        Vector3 miss = target - EvaluateGrip(q);
        if (miss.magnitude > 0.001f)
        {
            Debug.LogWarning($"Robot arm cannot reach {target:F3}: {miss.magnitude * 1000f:F1} mm short");
        }

        Apply(pose);   // solving moved the real joints, so put them back
        return q;
    }

    float YawToward(Vector3 target)
    {
        Vector3 local = transform.InverseTransformPoint(target);
        // The arm's forward at Axis1 = 0 is local -Z. A positive turn about +Y swings it toward local -X.
        return Mathf.Atan2(-local.x, -local.z) * Mathf.Rad2Deg;
    }

    Vector3 EvaluateGrip(float[] q)
    {
        Apply(q);
        return gripPoint.position;
    }

    float[] Residual(float[] q, Vector3 target, float tiltWeight)
    {
        Vector3 error = target - EvaluateGrip(q);
        float tilt = Vector3.Angle(gripPoint.forward, Vector3.down);
        return new[] { error.x, error.y, error.z, -tilt * tiltWeight };
    }

    // Solves (JtJ + dI) x = Jt r by Gaussian elimination
    static float[] SolveNormalEquations(float[,] j, float[] r, float damping)
    {
        double[,] a = new double[4, 5];
        for (int row = 0; row < 4; row++)
        {
            for (int col = 0; col < 4; col++)
            {
                double sum = row == col ? damping : 0.0;
                for (int k = 0; k < 4; k++) sum += j[k, row] * j[k, col];
                a[row, col] = sum;
            }
            double rhs = 0.0;
            for (int k = 0; k < 4; k++) rhs += j[k, row] * r[k];
            a[row, 4] = rhs;
        }

        for (int pivot = 0; pivot < 4; pivot++)
        {
            int best = pivot;
            for (int row = pivot + 1; row < 4; row++)
            {
                if (System.Math.Abs(a[row, pivot]) > System.Math.Abs(a[best, pivot])) best = row;
            }
            for (int col = 0; col < 5; col++)
            {
                double swap = a[pivot, col];
                a[pivot, col] = a[best, col];
                a[best, col] = swap;
            }
            for (int row = 0; row < 4; row++)
            {
                if (row == pivot || a[pivot, pivot] == 0.0) continue;
                double factor = a[row, pivot] / a[pivot, pivot];
                for (int col = pivot; col < 5; col++) a[row, col] -= factor * a[pivot, col];
            }
        }

        float[] x = new float[4];
        for (int i = 0; i < 4; i++) x[i] = a[i, i] == 0.0 ? 0f : (float)(a[i, 4] / a[i, i]);
        return x;
    }
}

using System.Collections.Concurrent;
using UnityEngine;

[System.Serializable]
public class LineStatePayload
{
    public string mode;          // "step" or "full"
    public string phase;         // idle, running, waiting, done, resetting, or offline (sent when Play stops)
    public int step;             // current or last step, 0 = not started
    public int stepCount;
    public string state;         // the same text as WarehouseCycle.state
    public string[] steps;       // step names
    public float[] stepSeconds;  // time of each finished step, 0 = not done yet
    public int shelfStored;      // boxes in the shelf
    public int shelfCapacity;
    public string timestamp;
}

// Node-RED <-> WarehouseCycle over MQTT.
// Commands in  (plain text on <baseTopic>/command): start, next, reset, mode_step, mode_full, empty_shelf
// State out    (JSON on <baseTopic>/state, retained): published every time something changes
public class LineMqttBridge : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private MQTTCore mqttCore;
    [SerializeField] private WarehouseCycle cycle;

    [Header("MQTT")]
    [SerializeField] private string baseTopic = "dgt/warehouse/line";

    string CommandTopic => baseTopic + "/command";
    string StateTopic => baseTopic + "/state";

    readonly ConcurrentQueue<string> commands = new ConcurrentQueue<string>();
    volatile bool subscribeRequested;
    string lastPublished;

    void OnEnable()
    {
        MQTTCore.OnMessageReceived += OnMqttMessage;
        MQTTCore.OnConnected += OnMqttConnected;
    }

    void OnDisable()
    {
        MQTTCore.OnMessageReceived -= OnMqttMessage;
        MQTTCore.OnConnected -= OnMqttConnected;
    }

    void OnApplicationQuit()
    {
        // Tell the dashboard Unity has stopped, so it does not keep showing a running line
        if (mqttCore.IsConnected) mqttCore.Publish(StateTopic, JsonUtility.ToJson(Snapshot(false)), true);
    }

    // Runs on the MQTT thread: only queue the work here
    void OnMqttConnected()
    {
        subscribeRequested = true;
    }

    void OnMqttMessage(string topic, string payload)
    {
        if (topic == CommandTopic) commands.Enqueue(payload.Trim().ToLower());
    }

    void Update()
    {
        if (subscribeRequested)
        {
            subscribeRequested = false;
            mqttCore.Subscribe(CommandTopic);
            lastPublished = null;   // publish the state again after every (re)connect
        }

        while (commands.TryDequeue(out string command)) Handle(command);

        PublishIfChanged();
    }

    void Handle(string command)
    {
        switch (command)
        {
            case "start": cycle.TryStartCycle(); break;
            case "next": cycle.Next(); break;
            case "reset": cycle.TryReset(); break;
            case "mode_step": cycle.SetMode(true); break;
            case "mode_full": cycle.SetMode(false); break;
            case "empty_shelf": cycle.TryEmptyShelf(); break;
            default: Debug.LogWarning($"[Line MQTT] ignored '{command}': use start, next, reset, mode_step, mode_full or empty_shelf"); break;
        }
    }

    void PublishIfChanged()
    {
        if (!mqttCore.IsConnected) return;

        LineStatePayload state = Snapshot(true);
        string json = JsonUtility.ToJson(state);
        if (json == lastPublished) return;
        lastPublished = json;

        state.timestamp = System.DateTime.Now.ToString("HH:mm:ss");   // not part of the comparison
        mqttCore.Publish(StateTopic, JsonUtility.ToJson(state), true);
    }

    LineStatePayload Snapshot(bool online)
    {
        int count = cycle.StepCount;
        string[] names = new string[count];
        float[] seconds = new float[count];
        System.Array.Copy(WarehouseCycle.StepNames, names, count);
        for (int i = 0; i < count; i++) seconds[i] = Mathf.Round(cycle.StepTimes[i] * 10f) / 10f;

        return new LineStatePayload
        {
            mode = cycle.settings.stepByStep ? "step" : "full",
            phase = online ? cycle.Phase : "offline",
            step = cycle.Step,
            stepCount = count,
            state = online ? cycle.state : "Unity stopped",
            steps = names,
            stepSeconds = seconds,
            shelfStored = cycle.ShelfStored,
            shelfCapacity = cycle.shelf.Slots.Length
        };
    }
}

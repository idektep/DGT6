using System.Collections;
using UnityEngine;

// The control panel for the whole line: change the settings here, even while playing, and compare the results.
// One cycle: conveyor -> robot arm 2 -> AGV -> robot arm 1 -> Cartesian -> warehouse slot,
// then the AGV and Cartesian go back to the start.
public class WarehouseCycle : MonoBehaviour
{
    public enum SlotChoice { NextEmpty, S01, S02, S03, S04, S05, S06 }

    [System.Serializable]
    public class Settings
    {
        [Header("Process")]
        [Tooltip("Which slot the box goes into. NextEmpty fills S01 to S06 in order.")]
        public SlotChoice slot = SlotChoice.NextEmpty;

        [Tooltip("Stop before each step and wait for Next (Space), so every step can be watched and discussed. Off = full loop.")]
        public bool stepByStep = false;

        [Tooltip("Run only steps 1 to 4 (conveyor to the AGV at robot arm 1), then wait for Reset.")]
        public bool stopAfterStep4 = false;

        [Tooltip("Seconds to wait before each step. It is not counted in the cycle time.")]
        [Range(0f, 5f)] public float pauseBetweenSteps = 0f;

        [Tooltip("Start the next cycle automatically until the warehouse is full.")]
        public bool repeatUntilFull = false;

        [Header("Conveyor")]
        [Tooltip("Belt speed (m/s).")]
        [Range(0.02f, 0.5f)] public float conveyorSpeed = 0.1f;

        [Header("AGV")]
        [Tooltip("Driving speed (m/s).")]
        [Range(0.02f, 0.5f)] public float agvSpeed = 0.15f;

        [Tooltip("Turning speed (degrees/s).")]
        [Range(15f, 360f)] public float agvTurnSpeed = 90f;

        [Header("Robot arms (both use the same settings)")]
        [Tooltip("Speed of the joint with the furthest to go (degrees/s). The other joints finish at the same time.")]
        [Range(10f, 180f)] public float armJointSpeed = 45f;

        [Tooltip("Speed of the gripper fingers (m/s).")]
        [Range(0.002f, 0.05f)] public float gripperSpeed = 0.01f;

        [Tooltip("How far above a pick or drop point the gripper moves in and out (m).")]
        [Range(0.02f, 0.08f)] public float hoverHeight = 0.05f;

        [Tooltip("How close to the arm's base the box stays while it swings across (m).")]
        [Range(0.09f, 0.15f)] public float carryRadius = 0.12f;

        [Tooltip("How high the box stays while it swings across (m). The end of the Y axis is 0.114 m high.")]
        [Range(0.12f, 0.18f)] public float carryHeight = 0.15f;

        [Header("Cartesian")]
        [Tooltip("Speed of the X, Y and Z axes (m/s).")]
        [Range(0.02f, 0.5f)] public float cartesianSpeed = 0.2f;

        [Tooltip("Distance from the rack centre where the box lines up with its column and row (m). The rack's front face is at 0.042 m.")]
        [Range(0.06f, 0.12f)] public float frontDistance = 0.077f;

        [Tooltip("How far the box is lifted to clear the front of the cell (m). The cell's lip is 5 mm high: try 0 and watch the box pass through it.")]
        [Range(0f, 0.02f)] public float insertLift = 0.006f;
    }

    public Settings settings = new Settings();

    [Header("Results (read only)")]
    public string state = "Ready: press Space";
    public int boxesStored;
    public float conveyorSeconds;
    public float loadArmSeconds;
    public float agvToArmSeconds;
    public float armSeconds;
    public float cartesianSeconds;
    public float returnSeconds;
    public float cycleSeconds;

    [Header("Equipment")]
    public Transform conveyorStart;     // load end of the belt: a new box appears here (box centre)
    public Transform conveyorEnd;       // unload end of the belt: robot arm 2 picks here (box centre)
    public ConveyorBeltMotion conveyorBelt;   // the belt surface moves with the box
    public ArmPickPlace conveyorArm;    // robot arm 2: conveyor -> AGV
    public AgvShuttle agv;
    public ArmPickPlace arm;            // robot arm 1: AGV -> Cartesian
    public SmartShelfController shelf;
    public CartesianAxes cartesian;
    public Transform handover;          // CartesianInput: where the arm puts the box on the fork

    [Header("Box")]
    public GameObject boxPrefab;
    public Vector3 boxOnDeck = new Vector3(0f, 0.01f, 0.04f);   // where arm 2 puts the box: on the AGV's centre line, so both arms reach it the same way

    public static readonly string[] StepNames =
    {
        "Conveyor to robot arm 2", "Robot arm 2 picks from the conveyor", "Robot arm 2 places on the AGV",
        "AGV drives to robot arm 1", "Robot arm 1 picks from the AGV", "Robot arm 1 places on the Cartesian",
        "Cartesian stores the box", "AGV and Cartesian go home"
    };

    // Read by LineMqttBridge and LineMonitorOverlay
    public int StepCount => settings.stopAfterStep4 ? 4 : 8;
    public int Step => step;
    public float[] StepTimes => stepTimes;
    public string Phase => resetting ? "resetting" : waitingForNext ? "waiting" : running ? "running" : needsReset ? "done" : "idle";

    bool running;
    bool waitingForNext;
    bool needsReset;        // steps 1 to 4 finished: the AGV is at robot arm 1
    bool resetting;
    int step;
    float stepSeconds;
    float[] stepTimes = new float[8];
    Transform currentBox;   // the box on its way through the line

    void Start()
    {
        ApplySettings();
        SetState("Ready: press Start");
    }

    void Update()
    {
        ApplySettings();
        if (Input.GetKeyDown(KeyCode.Space)) Next();
    }

    // Space: go on to the next step if one is waiting, otherwise start a cycle
    public void Next()
    {
        if (waitingForNext) waitingForNext = false;
        else TryStartCycle();
    }

    public void SetMode(bool stepByStep)
    {
        settings.stepByStep = stepByStep;
        if (!stepByStep) waitingForNext = false;   // switching to full loop carries on at once
    }

    public bool TryStartCycle()
    {
        if (running || resetting) return false;

        if (needsReset)
        {
            SetState("The AGV is at robot arm 1: press Reset first");
            return false;
        }

        if (shelf.IsBusy || shelf.WaitingBox != null || !cartesian.AtHome)
        {
            SetState("The Cartesian is busy: wait for it, or press R to clear it");
            return false;
        }

        ShelfSlot slot = ChooseSlot();
        if (slot == null) return false;

        StartCoroutine(RunCycle(slot));
        return true;
    }

    IEnumerator RunCycle(ShelfSlot slot)
    {
        running = true;
        step = 0;
        System.Array.Clear(stepTimes, 0, stepTimes.Length);
        string itemId = "BOX" + (boxesStored + 1).ToString("000");

        currentBox = Instantiate(boxPrefab, conveyorStart.position, Quaternion.identity).transform;
        yield return DoStep("Conveyor carrying " + itemId + " to robot arm 2", CarryOnConveyor(currentBox));
        conveyorSeconds = stepSeconds;

        yield return DoStep("Robot arm 2 picking " + itemId + " from the conveyor", conveyorArm.Pick(currentBox));
        loadArmSeconds = stepSeconds;

        yield return DoStep("Robot arm 2 placing " + itemId + " on the AGV", conveyorArm.Place(agv.deck.TransformPoint(boxOnDeck)));
        loadArmSeconds += stepSeconds;
        currentBox.SetParent(agv.deck, true);   // ride along with the AGV

        yield return DoStep("AGV driving to robot arm 1", agv.DriveToStop());
        agvToArmSeconds = stepSeconds;

        if (settings.stopAfterStep4)
        {
            needsReset = true;
            running = false;
            SetState("Steps 1 to 4 done: " + itemId + " is at robot arm 1, press Reset");
            yield break;
        }

        yield return DoStep("Robot arm 1 picking " + itemId + " from the AGV", arm.Pick(currentBox));
        armSeconds = stepSeconds;

        yield return DoStep("Robot arm 1 placing " + itemId + " on the Cartesian fork", arm.Place(handover.position));
        armSeconds += stepSeconds;

        yield return DoStep("Cartesian storing " + itemId + " in " + slot.SlotId, Store(itemId, slot));
        cartesianSeconds = stepSeconds;
        currentBox = null;   // the shelf has it now

        yield return DoStep("AGV and Cartesian going back to the start", GoHome());
        returnSeconds = stepSeconds;

        cycleSeconds = conveyorSeconds + loadArmSeconds + agvToArmSeconds + armSeconds + cartesianSeconds + returnSeconds;

        SetState("Ready: press Start");
        running = false;

        if (settings.repeatUntilFull) TryStartCycle();
    }

    // Empties every shelf slot, like the R key. Only while the line is idle.
    public bool TryEmptyShelf()
    {
        if (running || resetting) return false;
        shelf.ResetAll();
        SetState("Shelf emptied: press Start");
        return true;
    }

    public int ShelfStored
    {
        get
        {
            int stored = 0;
            foreach (ShelfSlot slot in shelf.Slots) if (!slot.IsFree) stored++;
            return stored;
        }
    }

    // Stops steps 1 to 4 wherever they are, removes the box and sends the arms and the AGV back to the start
    public bool TryReset()
    {
        if (resetting) return false;
        if (running && step > 4)
        {
            Debug.LogWarning("[Warehouse] Reset only works during steps 1 to 4: wait for the cycle to finish");
            return false;
        }

        StopAllCoroutines();
        running = false;
        waitingForNext = false;
        StartCoroutine(ResetLine());
        return true;
    }

    IEnumerator ResetLine()
    {
        resetting = true;
        SetState("Reset: robot arms and AGV going back to the start");
        if (currentBox != null) Destroy(currentBox.gameObject);
        currentBox = null;

        yield return conveyorArm.GoHome();
        yield return arm.GoHome();
        yield return agv.DriveHome();

        step = 0;
        System.Array.Clear(stepTimes, 0, stepTimes.Length);
        needsReset = false;
        resetting = false;
        SetState("Ready: press Start");
    }

    IEnumerator DoStep(string description, IEnumerator work)
    {
        step++;
        string title = "Step " + step + " of " + StepCount + ": " + description;

        if (step > 1 && settings.stepByStep)
        {
            SetState("Press Next for s" + title.Substring(1));
            waitingForNext = true;
            yield return new WaitWhile(() => waitingForNext);
        }
        else if (step > 1 && settings.pauseBetweenSteps > 0f)
        {
            SetState("Pause before s" + title.Substring(1));
            yield return new WaitForSeconds(settings.pauseBetweenSteps);
        }

        SetState(title);
        float started = Time.time;
        yield return work;
        stepSeconds = Time.time - started;
        stepTimes[step - 1] = stepSeconds;
    }

    IEnumerator CarryOnConveyor(Transform box)
    {
        while (box.position != conveyorEnd.position)
        {
            Vector3 before = box.position;
            box.position = Vector3.MoveTowards(box.position, conveyorEnd.position, settings.conveyorSpeed * Time.deltaTime);
            conveyorBelt.Carry(box.position - before);
            yield return null;
        }
    }

    IEnumerator Store(string itemId, ShelfSlot slot)
    {
        cartesian.holdAtSlot = true;
        if (shelf.AcceptIncomingBox(currentBox.gameObject, itemId) && shelf.RequestPlace("CYCLE-" + itemId, itemId, slot.SlotId))
        {
            yield return new WaitWhile(() => shelf.IsBusy);
        }
        else
        {
            Debug.LogWarning("The shelf refused " + itemId + ": is another box waiting at the Cartesian?");
        }
        if (slot.State == ShelfSlotState.OCCUPIED) boxesStored++;
    }

    IEnumerator GoHome()
    {
        cartesian.holdAtSlot = false;
        yield return agv.DriveHome();
        yield return new WaitUntil(() => cartesian.AtHome);
    }

    ShelfSlot ChooseSlot()
    {
        if (settings.slot == SlotChoice.NextEmpty)
        {
            foreach (ShelfSlot empty in shelf.Slots)
            {
                if (empty.IsFree) return empty;
            }
            SetState("Warehouse is full: press R to empty it");
            return null;
        }

        ShelfSlot slot = shelf.FindSlot(settings.slot.ToString());
        if (slot.IsFree) return slot;

        SetState(slot.SlotId + " already has a box: choose another slot, or press R to empty the warehouse");
        return null;
    }

    void ApplySettings()
    {
        agv.speed = settings.agvSpeed;
        agv.turnSpeed = settings.agvTurnSpeed;

        foreach (ArmPickPlace a in new[] { arm, conveyorArm })
        {
            a.jointSpeed = settings.armJointSpeed;
            a.fingerSpeed = settings.gripperSpeed;
            a.hoverHeight = settings.hoverHeight;
            a.carryRadius = settings.carryRadius;
            a.carryHeight = settings.carryHeight;
        }

        shelf.SetMotion(settings.cartesianSpeed, settings.frontDistance, settings.insertLift);
        cartesian.returnSpeed = settings.cartesianSpeed;
    }

    [ContextMenu("Restore default settings")]
    void RestoreDefaultSettings()
    {
        settings = new Settings();
    }

    void SetState(string newState)
    {
        state = newState;
        Debug.Log("[Warehouse] " + newState);
    }
}

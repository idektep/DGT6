using System.Collections;
using UnityEngine;

// Drives the AGV straight to its stop point and back, turning on the spot.
public class AgvShuttle : MonoBehaviour
{
    public Transform stopPoint;
    public Transform deck;              // top of the AGV, where a box sits

    [HideInInspector] public float speed = 0.15f;       // m/s, set by WarehouseCycle
    [HideInInspector] public float turnSpeed = 90f;     // degrees/s, set by WarehouseCycle

    Vector3 startPosition;
    Quaternion startRotation;

    void Awake()
    {
        startPosition = transform.position;
        startRotation = transform.rotation;
    }

    public IEnumerator DriveToStop()
    {
        yield return DriveTo(stopPoint.position);
    }

    // Turn around, drive back, then face the way it started so the next run is the same
    public IEnumerator DriveHome()
    {
        yield return DriveTo(startPosition);
        yield return Turn(startRotation);
    }

    IEnumerator DriveTo(Vector3 target)
    {
        target.y = transform.position.y;
        if (target == transform.position) yield break;   // already there (e.g. Reset before the AGV moved)
        yield return Turn(Quaternion.LookRotation(target - transform.position));
        while (transform.position != target)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
            yield return null;
        }
    }

    IEnumerator Turn(Quaternion heading)
    {
        while (transform.rotation != heading)
        {
            transform.rotation = Quaternion.RotateTowards(transform.rotation, heading, turnSpeed * Time.deltaTime);
            yield return null;
        }
        transform.rotation = heading;   // != stops within ~0.2 degrees, so snap exactly
    }
}

using UnityEngine;

// Monitor panel drawn over the Game view: MQTT link, mode, the step list and the current state.
public class LineMonitorOverlay : MonoBehaviour
{
    [SerializeField] private WarehouseCycle cycle;
    [SerializeField] private MQTTCore mqttCore;
    [SerializeField] private Rect area = new Rect(10, 10, 380, 400);

    GUIStyle label;

    void OnGUI()
    {
        if (label == null) label = new GUIStyle(GUI.skin.label) { richText = true, fontSize = 14, wordWrap = true };

        GUILayout.BeginArea(area, GUI.skin.box);
        GUILayout.Label("<b>Warehouse line monitor</b>", label);

        string link = mqttCore.IsConnected ? "<color=#4caf50>connected</color>" : "<color=#f44336>not connected</color>";
        GUILayout.Label($"MQTT: {link}  ({mqttCore.broker})", label);

        string mode = cycle.settings.stepByStep ? "Step-by-step" : "Full loop";
        GUILayout.Label($"Mode: <b>{mode}</b>     Phase: <b>{cycle.Phase}</b>", label);
        GUILayout.Space(4);

        for (int i = 0; i < cycle.StepCount; i++)
        {
            int number = i + 1;
            string color, mark;   // done / running now / waiting for Next / not yet
            if (number < cycle.Step || (number == cycle.Step && cycle.Phase == "done")) { color = "#4caf50"; mark = "OK"; }
            else if (number == cycle.Step && cycle.Phase == "running") { color = "#ffc107"; mark = ">>"; }
            else if (number == cycle.Step && cycle.Phase == "waiting") { color = "#2196f3"; mark = "||"; }
            else { color = "#9e9e9e"; mark = "--"; }

            string time = cycle.StepTimes[i] > 0f ? $"  {cycle.StepTimes[i]:F1} s" : "";
            GUILayout.Label($"<color={color}>{mark}  {number}. {WarehouseCycle.StepNames[i]}{time}</color>", label);
        }

        GUILayout.Space(4);
        GUILayout.Label($"<i>{cycle.state}</i>", label);
        GUILayout.EndArea();
    }
}

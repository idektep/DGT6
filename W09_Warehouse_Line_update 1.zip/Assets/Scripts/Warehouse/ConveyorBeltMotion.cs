using UnityEngine;

// Moves the ribs of the conveyor belt (Warehouse/ConveyorBelt shader) by exactly as far as the box moves,
// so the belt surface and the box travel together. Sits on the ANANT_C500_Track prefab.
public class ConveyorBeltMotion : MonoBehaviour
{
    [SerializeField] private Renderer belt;   // the Track model

    static readonly int OffsetId = Shader.PropertyToID("_Offset");
    MaterialPropertyBlock block;
    float offset;

    // boxMove: how far the box moved on the belt this frame (world space)
    public void Carry(Vector3 boxMove)
    {
        // The ribs on the top run sit at (position + offset): to move them along +Z, the offset goes down
        offset -= Vector3.Dot(boxMove, belt.transform.forward);

        if (block == null) block = new MaterialPropertyBlock();
        belt.GetPropertyBlock(block);
        block.SetFloat(OffsetId, offset);
        belt.SetPropertyBlock(block);
    }
}

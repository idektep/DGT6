// Conveyor belt with rubber ribs that can move. The Track model has no UVs, so the ribs are drawn from the
// position along the belt (the object's Z axis, in metres). ConveyorBeltMotion sets _Offset as the box travels:
// the ribs on the top run move with the box, the ribs on the return run underneath move the other way.
Shader "Warehouse/ConveyorBelt"
{
    Properties
    {
        _Color ("Belt colour", Color) = (0.03, 0.03, 0.03, 1)
        _RibColor ("Rib colour", Color) = (0.18, 0.18, 0.18, 1)
        _Spacing ("Rib spacing (m)", Float) = 0.02
        _RibWidth ("Rib width (part of the spacing)", Range(0.05, 0.95)) = 0.3
        _Glossiness ("Smoothness", Range(0, 1)) = 0.2
        _Offset ("Belt travel (m), set by ConveyorBeltMotion", Float) = 0
    }
    SubShader
    {
        Tags { "RenderType" = "Opaque" }

        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows vertex:vert
        #pragma target 3.0

        fixed4 _Color;
        fixed4 _RibColor;
        float _Spacing;
        float _RibWidth;
        half _Glossiness;
        float _Offset;

        struct Input
        {
            float2 belt;   // x: distance along the belt, y: height above the belt's centre (both in metres)
        };

        void vert(inout appdata_full v, out Input o)
        {
            UNITY_INITIALIZE_OUTPUT(Input, o);
            // Measured in world units along the object's own axes, so the import scale does not matter
            float3 fromCentre = mul(unity_ObjectToWorld, v.vertex).xyz - unity_ObjectToWorld._m03_m13_m23;
            o.belt.x = dot(fromCentre, normalize(unity_ObjectToWorld._m02_m12_m22));
            o.belt.y = dot(fromCentre, normalize(unity_ObjectToWorld._m01_m11_m21));
        }

        void surf(Input IN, inout SurfaceOutputStandard o)
        {
            // Top run and return run move in opposite directions, like a real belt loop
            float position = IN.belt.y >= 0 ? IN.belt.x + _Offset : IN.belt.x - _Offset;
            float rib = step(frac(position / _Spacing), _RibWidth);
            o.Albedo = lerp(_Color.rgb, _RibColor.rgb, rib);
            o.Smoothness = _Glossiness;
        }
        ENDCG
    }
    FallBack "Diffuse"
}
